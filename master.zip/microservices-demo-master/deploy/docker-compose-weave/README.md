See the [documentation](https://microservices-demo.github.io/microservices-demo/deployment/docker-compose-weave.html) on how to deploy Sock Shop using Docker Compose and Weave.
