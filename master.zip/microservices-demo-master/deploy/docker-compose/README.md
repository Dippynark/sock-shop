See the [documentation](https://microservices-demo.github.io/microservices-demo/deployment/docker-compose.html) on how to deploy Sock Shop using Docker Compose.
