See the [documentation](https://microservices-demo.github.io/microservices-demo/deployment/apcera.html) on how to deploy Sock Shop on Apcera.
