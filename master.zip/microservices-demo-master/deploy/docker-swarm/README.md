See the [documentation](https://microservices-demo.github.io/microservices-demo/deployment/docker-swarm.html) on how to deploy Sock Shop using Docker Swarm.
